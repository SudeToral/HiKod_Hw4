import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(WeatherApp());
}

class WeatherApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Hava Durumu'),
        ),
        body: Center(
          child: FutureBuilder<List<WeatherData>>(
            future: fetchWeatherForRandomCities(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return CircularProgressIndicator();
              } else if (snapshot.hasError) {
                return Text("Hata Oluştu \n ${snapshot.error}");
              } else if (snapshot.hasData) {
                final weatherDataList = snapshot.data;
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (var weatherData in weatherDataList!)
                      WeatherInfo(weatherData: weatherData),
                    Divider(), // Her şehir arasında bir çizgi ekler
                  ],
                );
              } else {
                return Text("Veri Yok");
              }
            },
          ),
        ),
      ),
    );
  }
}

Future<List<WeatherData>> fetchWeatherForRandomCities() async {
  final apiKey = '828f37465dmsha598843c4d144aep1e4a99jsn6bad46f165a0';
  final host = 'weatherapi-com.p.rapidapi.com';

  final randomCities = ['Kisumu', 'New York', 'Paris', 'Tokyo', 'Sydney'];

  final List<WeatherData> weatherDataList = [];

  for (final city in randomCities) {
    final response = await http.get(
      Uri.parse('https://$host/current.json?q=$city'),
      headers: {
        'X-RapidAPI-Key': apiKey,
        'X-RapidAPI-Host': host,
      },
    );

    if (response.statusCode == 200) {
      final weatherData = WeatherData.fromJson(jsonDecode(response.body));
      weatherDataList.add(weatherData);
    } else {
      // Hata durumu işleniyor
      print("HTTP İstek Hatası (${city}): ${response.statusCode}");
    }
  }

  return weatherDataList;
}

class WeatherData {
  final String location;
  final double temperature;
  final int humidity;
  final double windspeed;

  WeatherData({
    required this.location,
    required this.temperature,
    required this.humidity,
    required this.windspeed,
  });

  factory WeatherData.fromJson(Map<String, dynamic> json) {
    return WeatherData(
      location: json['location']['name'],
      temperature: json['current']['temp_c'].toDouble(),
      humidity: json['current']['humidity'],
      windspeed: json['current']['wind_kph'].toDouble(),
    );
  }
}

class WeatherInfo extends StatelessWidget {
  final WeatherData weatherData;
  WeatherInfo({required this.weatherData});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Location: ${weatherData.location}",
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        Text(
          "Temperature: ${weatherData.temperature}°C",
          style: TextStyle(fontSize: 16),
        ),
        Text(
          "Humidity: ${weatherData.humidity}%",
          style: TextStyle(fontSize: 16),
        ),
        Text(
          "Wind Speed: ${weatherData.windspeed} km/saat",
          style: TextStyle(fontSize: 16),
        ),
        Divider(), // Her şehir arasında bir çizgi ekler
      ],
    );
  }
}
